#include <stdlib.h>
#include "expression_stack.h"

void Expression_stack_init(Expression_stack* stack)
{
	stack->top = NULL;
}


bool Expression_stack_push(Expression_stack* stack, Symbol_enumeration symbol, Data_type type)
{
	Expression_stack_item* new_item = (Expression_stack_item*)malloc(sizeof(Expression_stack_item));

	if (new_item == NULL)
		return false;

	new_item->symbol = symbol;
	new_item->data_type = type;
	new_item->next = stack->top;

	stack->top = new_item;

	return true;
}


bool Expression_stack_pop(Expression_stack* stack)
{
	if (stack->top != NULL)
	{
		Expression_stack_item* pointer = stack->top;
		stack->top = pointer->next;
		free(pointer);

		return true;
	}
	return false;
}


void Expression_stack_pop_count(Expression_stack* stack, int count)
{
	for (int counter = 0; counter < count; counter++)
	{
		Expression_stack_pop(stack);
	}
}


Expression_stack_item* symbol_stack_top_terminal(Expression_stack* stack)
{
	for (Expression_stack_item* pointer = stack->top; pointer != NULL; pointer = pointer->next)
	{
		if (pointer->symbol < SYMBOL_STOP)
			return pointer;
	}

	return NULL;
}


bool Expression_stack_insert_after_top_terminal(Expression_stack* stack, Symbol_enumeration symbol, Data_type type)
{
    Expression_stack_item* prev = NULL;

	for (Expression_stack_item* pointer = stack->top; pointer != NULL; pointer = pointer->next)
	{
		if (pointer->symbol < SYMBOL_STOP)
		{
            Expression_stack_item* new_item = (Expression_stack_item*)malloc(sizeof(Expression_stack_item));

			if (new_item == NULL)
				return false;

			new_item->symbol = symbol;
			new_item->data_type = type;

			if (prev == NULL)
			{
				new_item->next = stack->top;
				stack->top = new_item;
			}
			else
			{
				new_item->next = prev->next;
				prev->next = new_item;
			}

			return true;
		}

		prev = pointer;
	}

	return false;
}


Expression_stack_item* symbol_stack_top(Expression_stack* stack)
{
	return stack->top;
}


void Expression_stack_free(Expression_stack* stack)
{
	while (Expression_stack_pop(stack));
}
